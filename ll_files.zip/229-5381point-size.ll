; ModuleID = './code/229-5381point-size.c'
source_filename = "./code/229-5381point-size.c"
target datalayout = "e-m:o-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx14.0.0"

%struct.A = type { i32, i8, [128 x i8] }

@.str = private unnamed_addr constant [9 x i8] c"%s %d : \00", align 1
@__func__.main = private unnamed_addr constant [5 x i8] c"main\00", align 1
@.str.1 = private unnamed_addr constant [19 x i8] c"sizeof(a) = [%ld]\0A\00", align 1
@.str.2 = private unnamed_addr constant [20 x i8] c"sizeof(&a) = [%ld]\0A\00", align 1
@.str.3 = private unnamed_addr constant [19 x i8] c"sizeof(p) = [%ld]\0A\00", align 1
@.str.4 = private unnamed_addr constant [20 x i8] c"sizeof(*p) = [%ld]\0A\00", align 1

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i32 @main(i32 noundef %argc, ptr noundef %argv) #0 {
entry:
  %retval = alloca i32, align 4
  %argc.addr = alloca i32, align 4
  %argv.addr = alloca ptr, align 8
  %a = alloca %struct.A, align 4
  %p = alloca ptr, align 8
  store i32 0, ptr %retval, align 4
  store i32 %argc, ptr %argc.addr, align 4
  store ptr %argv, ptr %argv.addr, align 8
  br label %do.body

do.body:                                          ; preds = %entry
  %call = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @__func__.main, i32 noundef 34)
  %call1 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i64 noundef 136)
  br label %do.end

do.end:                                           ; preds = %do.body
  br label %do.body2

do.body2:                                         ; preds = %do.end
  %call3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @__func__.main, i32 noundef 35)
  %call4 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i64 noundef 8)
  br label %do.end5

do.end5:                                          ; preds = %do.body2
  store ptr %a, ptr %p, align 8
  br label %do.body6

do.body6:                                         ; preds = %do.end5
  %call7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @__func__.main, i32 noundef 37)
  %call8 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef 8)
  br label %do.end9

do.end9:                                          ; preds = %do.body6
  br label %do.body10

do.body10:                                        ; preds = %do.end9
  %call11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @__func__.main, i32 noundef 38)
  %call12 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, i64 noundef 136)
  br label %do.end13

do.end13:                                         ; preds = %do.body10
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone ssp uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a,+zcm,+zcz" }
attributes #1 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a,+zcm,+zcz" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 1}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Homebrew clang version 19.1.4"}
