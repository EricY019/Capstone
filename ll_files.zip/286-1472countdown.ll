; ModuleID = './code/286-1472countdown.c'
source_filename = "./code/286-1472countdown.c"
target datalayout = "e-m:o-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx14.0.0"

@.str = private unnamed_addr constant [5 x i8] c"\0D%2d\00", align 1
@__stdoutp = external global ptr, align 8
@.str.1 = private unnamed_addr constant [10 x i8] c"\0D\07FIRE!!\0A\00", align 1
@.str.2 = private unnamed_addr constant [40 x i8] c"After excute the program %.1f seconds.\0A\00", align 1

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i32 @sleep(i64 noundef %x) #0 {
entry:
  %retval = alloca i32, align 4
  %x.addr = alloca i64, align 8
  %c1 = alloca i64, align 8
  %c2 = alloca i64, align 8
  store i64 %x, ptr %x.addr, align 8
  %call = call i64 @"\01_clock"()
  store i64 %call, ptr %c1, align 8
  br label %do.body

do.body:                                          ; preds = %do.cond, %entry
  %call1 = call i64 @"\01_clock"()
  store i64 %call1, ptr %c2, align 8
  %cmp = icmp eq i64 %call1, -1
  br i1 %cmp, label %if.then, label %if.end

if.then:                                          ; preds = %do.body
  store i32 0, ptr %retval, align 4
  br label %return

if.end:                                           ; preds = %do.body
  br label %do.cond

do.cond:                                          ; preds = %if.end
  %0 = load i64, ptr %c2, align 8
  %1 = load i64, ptr %c1, align 8
  %sub = sub i64 %0, %1
  %conv = uitofp i64 %sub to double
  %mul = fmul double 1.000000e+03, %conv
  %div = fdiv double %mul, 1.000000e+06
  %2 = load i64, ptr %x.addr, align 8
  %conv2 = uitofp i64 %2 to double
  %cmp3 = fcmp olt double %div, %conv2
  br i1 %cmp3, label %do.body, label %do.end, !llvm.loop !5

do.end:                                           ; preds = %do.cond
  store i32 1, ptr %retval, align 4
  br label %return

return:                                           ; preds = %do.end, %if.then
  %3 = load i32, ptr %retval, align 4
  ret i32 %3
}

declare i64 @"\01_clock"() #1

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i32 @main() #0 {
entry:
  %retval = alloca i32, align 4
  %i = alloca i32, align 4
  %c = alloca i64, align 8
  store i32 0, ptr %retval, align 4
  store i32 10, ptr %i, align 4
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %entry
  %0 = load i32, ptr %i, align 4
  %cmp = icmp sgt i32 %0, 0
  br i1 %cmp, label %for.body, label %for.end

for.body:                                         ; preds = %for.cond
  %1 = load i32, ptr %i, align 4
  %call = call i32 (ptr, ...) @printf(ptr noundef @.str, i32 noundef %1)
  %2 = load ptr, ptr @__stdoutp, align 8
  %call1 = call i32 @fflush(ptr noundef %2)
  %call2 = call i32 @sleep(i64 noundef 1000)
  br label %for.inc

for.inc:                                          ; preds = %for.body
  %3 = load i32, ptr %i, align 4
  %dec = add nsw i32 %3, -1
  store i32 %dec, ptr %i, align 4
  br label %for.cond, !llvm.loop !7

for.end:                                          ; preds = %for.cond
  %call3 = call i32 (ptr, ...) @printf(ptr noundef @.str.1)
  %call4 = call i64 @"\01_clock"()
  store i64 %call4, ptr %c, align 8
  %4 = load i64, ptr %c, align 8
  %conv = uitofp i64 %4 to double
  %div = fdiv double %conv, 1.000000e+06
  %call5 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, double noundef %div)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

declare i32 @fflush(ptr noundef) #1

attributes #0 = { noinline nounwind optnone ssp uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a,+zcm,+zcz" }
attributes #1 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+ccdp,+ccidx,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8a,+zcm,+zcz" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 1}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"Homebrew clang version 19.1.4"}
!5 = distinct !{!5, !6}
!6 = !{!"llvm.loop.mustprogress"}
!7 = distinct !{!7, !6}
